// src/routes/AppRoutes.jsx


import { Routes, Route, Navigate } from 'react-router-dom';
import React from 'react';
import Home from '../pages/Home/Home';
import Login from '../pages/Auth/Login';
import Signup from '../pages/Auth/Signup';
import ForgotPassword from '../pages/Auth/ForgotPassword.jsx';
import Inbox from '../pages/Inbox/Inbox';
import ChatThread from '../pages/Chat/ChatThread';
import VerificationPending from '../pages/Auth/VerificationPending.jsx';
import VerifyEmail from '../pages/Auth/VerifyEmail.jsx';
import RideSearch from '../pages/RideSearch/RideSearch';
import RidePost from '../pages/RidePost/RidePost';
import Profile from '../pages/Profile/Profile.jsx';
import NotificationsPage from '../pages/NotificationsPage';
import MyBookings from '../pages/bookings/MyBookings.jsx';
import DriverRideRequests from '../pages/DriverRideRequests.jsx';
import { useAuth } from '../hooks/useAuth';
import PaymentSetupForm from '../pages/PaymentSetupForm.jsx';
import UpcomingRides from '../pages/rides/UpcomingRides';
import DriverUpcomingRides from '../pages/driver/DriverUpcomingRides';
import PaymentSuccess from "../pages/PaymentSuccess.jsx";
import PaymentFailed from "../pages/PaymentFailed.jsx";

// Footer Nav pages
import About from '../pages/FooterNavlinks/About.jsx';
import HowItWorks from '../pages/FooterNavlinks/HowItWorks.jsx';
import HelpCenter from '../pages/FooterNavlinks/HelpCenter.jsx';
import ContactUs from '../pages/FooterNavlinks/ContactUs.jsx';
import FAQ from '../pages/FooterNavlinks/FAQ.jsx';
import Guidelines from '../pages/FooterNavlinks/Guidelines.jsx';
import Blog from '../pages/FooterNavlinks/Blog.jsx';
import Report from '../pages/FooterNavlinks/Report.jsx';
import TermsAndConditions from '../pages/FooterNavlinks/TermsAndConditions.jsx';

// Admin pages
import AdminLogin from '../pages/Admin/AdminLogin.jsx';
import AdminDashboard from '../pages/Admin/AdminDashboard.jsx';

// ── Protected Route Component ──────────────────────────────────────────────
// FIX: read `isLoading` (the field useAuth actually exposes), not `loading`.
const ProtectedRoute = ({ children }) => {
  const { user, isLoading: loading } = useAuth();

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 to-purple-50">
        <div className="text-center">
          <div className="inline-block animate-spin rounded-full h-16 w-16 border-t-4 border-b-4 border-blue-600 mb-4"></div>
          <p className="text-gray-600 font-medium">Loading...</p>
        </div>
      </div>
    );
  }

  return user ? children : <Navigate to="/login" replace />;
};

// ── Public Route Component ──────────────────────────────────────────────────
// Same fix as ProtectedRoute above.
const PublicRoute = ({ children }) => {
  const { user, isLoading: loading } = useAuth();

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 to-purple-50">
        <div className="text-center">
          <div className="inline-block animate-spin rounded-full h-16 w-16 border-t-4 border-b-4 border-blue-600 mb-4"></div>
          <p className="text-gray-600 font-medium">Loading...</p>
        </div>
      </div>
    );
  }

  return !user ? children : <Navigate to="/" replace />;
};

// Admin Route Component
const AdminRoute = ({ children }) => {
  const isAdmin = localStorage.getItem('isAdminAuthenticated') === 'true';
  return isAdmin ? children : <Navigate to="/admin/login" replace />;
};

function AppRoutes() {
  return (
    <Routes>
      {/* Public Routes */}
      <Route path="/" element={<Home />} />

      {/* Admin Routes */}
      <Route path="/admin/login" element={<AdminLogin />} />
      <Route
        path="/admin/dashboard"
        element={
          <AdminRoute>
            <AdminDashboard />
          </AdminRoute>
        }
      />

      {/* Auth Routes */}
      <Route
        path="/login"
        element={
          <PublicRoute>
            <Login />
          </PublicRoute>
        }
      />

      <Route
        path="/forgot-password"
        element={
          <PublicRoute>
            <ForgotPassword />
          </PublicRoute>
        }
      />

      <Route
        path="/reset-password"
        element={
          <PublicRoute>
            <ForgotPassword />
          </PublicRoute>
        }
      />
      <Route
        path="/signup"
        element={
          <PublicRoute>
            <Signup />
          </PublicRoute>
        }
      />

      <Route
        path="/verification-pending"
        element={<VerificationPending />}
      />

      <Route
        path="/verify-email"
        element={<VerifyEmail />}
      />

      <Route path="/upcoming-rides" element={<UpcomingRides />} />
      <Route path="/driver/upcoming-rides" element={<DriverUpcomingRides />} />

      {/* Protected Routes */}
      <Route
        path="/ride/search"
        element={
          <ProtectedRoute>
            <RideSearch />
          </ProtectedRoute>
        }
      />
      <Route
        path="/ride/post"
        element={
          <ProtectedRoute>
            <RidePost />
          </ProtectedRoute>
        }
      />
      <Route
        path="/profile"
        element={
          <ProtectedRoute>
            <Profile />
          </ProtectedRoute>
        }
      />

      <Route
        path="/notifications"
        element={
          <ProtectedRoute>
            <NotificationsPage />
          </ProtectedRoute>
        }
      />

      <Route
        path="/bookings/my-bookings"
        element={
          <ProtectedRoute>
            <MyBookings />
          </ProtectedRoute>
        }
      />
      <Route
        path="/bookings/driver"
        element={
          <ProtectedRoute>
            <DriverRideRequests />
          </ProtectedRoute>
        }
      />
      <Route
        path="/driver/bookings"
        element={
          <ProtectedRoute>
            <DriverRideRequests />
          </ProtectedRoute>
        }
      />
      <Route
        path="/payment/setup"
        element={<ProtectedRoute><PaymentSetupForm /></ProtectedRoute>}
      />

      <Route path="/payment-success/:bookingId" element={<PaymentSuccess />} />
      <Route path="/payment-failed/:bookingId" element={<PaymentFailed />} />

      {/* Chat / Negotiation Routes (Milestone 3/4) */}
      <Route
        path="/messages"
        element={
          <ProtectedRoute>
            <Inbox />
          </ProtectedRoute>
        }
      />
      <Route
        path="/messages/:conversationId"
        element={
          <ProtectedRoute>
            <ChatThread />
          </ProtectedRoute>
        }
      />

      {/* Footer Nav Routes */}
      <Route path="/about" element={<About />} />
      <Route path="/how-it-works" element={<HowItWorks />} />
      <Route path="/help" element={<HelpCenter />} />
      <Route path="/contact" element={<ContactUs />} />
      <Route path="/faq" element={<FAQ />} />
      <Route path="/guidelines" element={<Guidelines />} />
      <Route path="/blog" element={<Blog />} />
      <Route path="/report" element={<Report />} />
      <Route path="/terms" element={<TermsAndConditions />} />
      <Route path="/privacy" element={<TermsAndConditions />} />

      {/* 404 Not Found Route */}
      <Route
        path="*"
        element={
          <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 to-purple-50 px-4">
            <div className="text-center">
              <div className="w-24 h-24 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-6">
                <svg className="w-12 h-12 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.172 16.172a4 4 0 015.656 0M9 10h.01M15 10h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
              </div>
              <h1 className="text-6xl font-bold text-gray-900 mb-4">404</h1>
              <h2 className="text-2xl font-semibold text-gray-800 mb-3">Page Not Found</h2>
              <p className="text-gray-600 mb-8 max-w-md mx-auto">
                The page you're looking for doesn't exist or has been moved.
              </p>
              <a
                href="/"
                className="inline-flex items-center gap-2 bg-gradient-to-r from-blue-600 to-blue-500 text-white px-6 py-3 rounded-lg font-semibold hover:from-blue-700 hover:to-blue-600 hover:shadow-lg transform hover:scale-105 transition-all duration-200"
              >
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" />
                </svg>
                Back to Home
              </a>
            </div>
          </div>
          
        }
      />
    </Routes>
  );
}

export default AppRoutes;